<?php

namespace PhpOffice\PhpSpreadsheet;

use RuntimeException;

class Exception extends RuntimeException
{
}
